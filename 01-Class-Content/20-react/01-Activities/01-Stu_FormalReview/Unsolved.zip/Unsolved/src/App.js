import React from "react";
import Form from "./components/Form";

const App = () => <Form />;

export default App;
